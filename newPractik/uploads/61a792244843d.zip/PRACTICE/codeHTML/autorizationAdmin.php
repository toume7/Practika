<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/autorizationAdmin.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
</head>
<body>
    <p>*Чтобы войти в режим админа введите данные ниже</p>
    <form action="../data/loginAdmin.php" method="post">
        <input type="text" name="login" placeholder="Логин..">
        <input type="text" name="pass" placeholder="Пароль..">
         <button type="submit">ВОЙТИ</button>
    </form>
    <?php
if ($_SESSION['message']) {
   echo '<p class="msg">' . $_SESSION['message'] . '</p> ';
}
unset($_SESSION['message']);
?>
</body>
</html>
