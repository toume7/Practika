<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/admin.css">
    <title>ADMIN</title>
</head>
<body>
    <h1>Вы в режиме админа</h1>
    <p>* Чтобы добавить книгу, зaполните форму ниже</p>
    <form action="../data/addbook.php" method="post" enctype="multipart/form-data">
        <input type="text" name="name" placeholder="Название.."><br>
        <input type="text" name="authors" placeholder="Авторы.."><br>
        <input type="date" name="year" placeholder="Дата написания.."><br>
        <input type="file" name="img"><br>
        <textarea name="description" placeholder="Краткое описание.."></textarea><br>
        <button type="submit">ДОБАВИТЬ</button>        
    </form>
    <button class="logOut"><a href="main.php">ВЫЙТИ</a></button>
</body>
</html>
