<?php
session_start();
require ('getbook.php') 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="/css/main.css">
    <title>ГЛАВНАЯ</title>
    </head>
    <body>
    <header>
        <button class="logo">V-BOOKS</button>
        <input type="text" name="search" placeholder="Поиск..">
        <button type="submit" class="search">ИСКАТЬ</button>
        <button type="submit" class="filter">Ф</button>
        <ul>
            <li>Жанры</li>
            <li>Авторы</li>
            <li>Моя библиотека</li>
            <li><a href="autorizationAdmin.php">Режим админа</a></li>
        </ul>
    </header>
    <section>
        <div class="allbooks">
            <?php
            foreach ($posts as $post);
            ?>
            <form action="viewbook.php" method="post" enctype="multipart/form-data">
            <div class="onebook">
                <img src="../../uploads<?= $post['img']>">
                <p class="name">Название: <?= $post['name']></p>
                <p class="authorsbook">Авторы:<?= $post['authors']></p>
                <p class="datewriting">Год:<?= $post['year']></p>
                <p class="description">Описание:<?= $post['descriptin']></p>
                <button>Открыть</button>
            </div>
            </form>
        </div>

    </section>
    <!-- <hr> -->
    <footer>
        <p>Как связаться с нами:</p><br>
        <div class="allfooter">
            <div class="allIcons">
                <a hred=""><img src="">VK</a>
                <a hred=""><img src="">INST</a>
                <a hred=""><img src="">PLACE</a>
            </div>
            <button class="logo">V-BOOKS</button>
            <p>Тех.поддержка: +7(989)-680-42-31</p>
        </div>
    </footer>
</body>

</html>