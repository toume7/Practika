<?php
session_start();
require_once 'connect.php';
$login = $_POST ['login'];
$pass = $_POST['pass'];
$user = $pdo->prepare("SELECT * FROM admin where `log`='$login' and `pass`='$pass'");
$user->execute();
$us = $user->fetchAll(PDO::FETCH_ASSOC);
if (!empty($us)) {
    header('Location: ../codeHTML/admin.php');
} else {
    header('Location: ../codeHTML/autorizationAdmin.php');
    $_SESSION['message'] = "Неверные данные!";
}
