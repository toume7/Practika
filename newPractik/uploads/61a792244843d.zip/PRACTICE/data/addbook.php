<?php
session_start();
require_once 'connect.php';
$img = $_FILES['img'];
$extention = pathinfo($img['name'],PATHINFO_EXTENSION);
$filename = uniqid().".".$extention;
move_uploaded_file($img['tmp_name'],"../uploads/".$filename); 

$sql = "INSERT INTO book (name,authors,year,image,description) VALUE (:name,:authors,:year,:img,:description)";
$statement = $pdo->prepare($sql);

$statement->bindParam(":name", $_POST['name']);
$statement->bindParam(":authors", $_POST['authors']);
$statement->bindParam(":year", $_POST['year']);
$statement->bindParam(":img", $filename);
$statement->bindParam(":description", $_POST['description']);
$statement->execute();
header("Location:../codeHTML/admin.php");
