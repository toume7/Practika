<?php
$pdo = new PDO("mysql:host=localhost;dbname=praktika","root","root");