$(document).ready(function (){
    let id=2;
    let ob={
        'id':2
    }
    $("#book").click(function () {
        // location.href="http://practik/html-css/admin/view_book.php?id="+id;
        $.ajax({
            type:"POST",
            url:"http://practik/php/getnewbook.php",
            dataType:'json',
            data:{
                id: id,
            },success:function (){
                alert("gdfgdg")
            }
        })
    })
});