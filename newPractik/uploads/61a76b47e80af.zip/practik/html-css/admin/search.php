<?php
session_start();
require_once '../../php/connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../user/index.css">
    <link rel="stylesheet" href="book.css">
    <link rel="stylesheet" href="../user/window.css">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div id="text">
    <form method="post" enctype="multipart/form-data">
        <input type="text" placeholder="Поиск.." name="search" required>
        <button type="submit">Поиск</button>
    </form>
    <a href="admin.php"><p>Главная</p></a>
    <a href="#zatemnenie"><p>Добавить книгу</p></a>
    <a href="../user/index.php"><p>Выйти</p></a>
</div>

<div id="main_book">
    <?php
    $booksk=[];
    $name = $_POST['search'];
    $book = $pdo->prepare("SELECT * FROM book where `name_book`='$name'");
    $book->execute();
    $books = $book->FetchAll(PDO::FETCH_ASSOC);
    if (empty($books)) {
        $autor = $pdo->prepare("SELECT * FROM author where `name`='$name' or`surname`='$name' or`sursurname`='$name'");
        $autor->execute();
        $authors = $autor->FetchAll(PDO::FETCH_ASSOC);
        foreach ($authors as $autor) {
            $id_a = $autor['id'];
            $id = $pdo->prepare("SELECT id_book FROM beetween WHERE `id_autor`='$id_a'");
            $id->execute();
            $ids = $id->FetchAll(PDO::FETCH_ASSOC);

            foreach ($ids as $id_b) {
                $temp_id_B = $id_b['id_book'];
                $book = $pdo->prepare("SELECT * FROM book where `id`='$temp_id_B'");
                $book->execute();
                $books = $book->FetchAll(PDO::FETCH_ASSOC);
                $booksk=array_merge($booksk,$books);
            }
        }
    }
    ?>


    <?php foreach ($booksk as $post): ?>
        <form action="view_book.php" method="POST" enctype="multipart/form-data">
            <div id="book">
                <img id="photo_glav" src="../../uploads/<?= $post['img']; ?>">
                <h2><?= $post['name_book'] ?></h2>
                <p id="description"> Автор(ы):<?php
                    $tmp_a = $post['id'];
                    $id = $pdo->prepare("SELECT id_autor FROM beetween WHERE `id_book`='$tmp_a'");
                    $id->execute();
                    $id = $id->FetchAll(PDO::FETCH_ASSOC);
                    foreach ($id as $i) {

                        $temp_i = $i['id_autor'];
                        $ids = intval($temp_i);
                        $author = $pdo->prepare("SELECT * FROM author where `id`='$ids'");
                        $author->execute();
                        $author = $author->FetchAll(PDO::FETCH_ASSOC);
                        $temp = $author['0'];
                        echo $temp['surname'], "  ";


                    }
                    ?></p>

                <p id="description"><?= $post['date_of_writing'] ?></p>
                <p id="description2"><?= $post['description']; ?></p>
                <button type="submit">Открыть</button>
            </div>

            <input id="id5" name="id" value="<?= $tmp_a ?>">

        </form>
    <?php endforeach; ?>
</div>
<div id="zatemnenie">
    <div id="name">
        <form id="form" action="../../php/addBook.php" method="post" enctype="multipart/form-data">
            <input type="text" name="name_book" placeholder="Название книги" required><br><br>
            <div id="div">
                <input type="text" name="name0" placeholder="Имя" required><br>
                <input type="text" name="surname0" placeholder="Фамилия" required><br>
                <input type="text" name="sursurname0" placeholder="Отчество"><br><br>

            </div>
            <button type="button" id="add">добавить автора</button>
            <br><br>

            <input type="file" name="img"><br>
            <input type="date" name="date_of_writing" required><BR>
            <textarea name="description" placeholder="Описание" required>    </textarea><br>


            <button type="submit">Добавить</button>
            <script language="JavaScript">
                let count = 0;
                document.getElementById('add').onclick = function () {
                    let div = document.createElement('div');
                    div.innerHTML = '<input type="text" name="name' + count + '"placeholder="Имя"required><br>' +
                        ' <input type="text" name="surname' + count + '"placeholder="Фамилия"required><br>' +
                        '<input type="text" name="sursurname' + count + '" placeholder="Отчество"><br><br>'
                    count++;
                    document.querySelector('#div').appendChild(div);
                }
            </script>
            <a href="#" class="close">Закрыть окно</a>
        </form>
    </div>
</div>
</body>
</html>