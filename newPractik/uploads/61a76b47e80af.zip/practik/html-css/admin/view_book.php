<?php
session_start();

require_once "../../php/getnewbook.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="../user/index.css">
    <link rel="stylesheet" href="../user/window.css">
    <link rel="stylesheet" href="main_book.css">
    <link rel="stylesheet" href="book.css">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div id="text">
    <form action="search.php" method="post" enctype="multipart/form-data">
        <input type="text" placeholder="Поиск.." name="search" required>
        <button type="submit">Поиск</button>
    </form>
    <a href="admin.php"><p>Главная</p></a>
    <a href="#zatemnenie"><p>Добавить книгу</p></a>
    <a href="../user/index.php"><p>Выйти</p></a>
</div>

<div id="back">

    <?php foreach ($posts

    as $post): ?>
    <img id="photo" src="../../uploads/<?= $post['img']; ?>">
    <h1><?= $post['name_book'] ?></h1>

    <p>Автор(ы):<?php
        $tmp_a = $post['id'];
        $id = $pdo->prepare("SELECT id_autor FROM beetween WHERE `id_book`='$tmp_a'");
        $id->execute();
        $id = $id->FetchAll(PDO::FETCH_ASSOC);
        foreach ($id as $i) {

            $temp_i = $i['id_autor'];
            $ids = intval($temp_i);
            $author = $pdo->prepare("SELECT * FROM author where `id`='$ids'");
            $author->execute();
            $author = $author->FetchAll(PDO::FETCH_ASSOC);
            $temp = $author['0'];
            echo $temp['name'], " ";
            echo $temp['surname'], "  ";


        }
        ?></p></p>
    <div id="div"><p id="description2"><?= $post['description'] ?></p></div>
    <p id="tt">Дата публикации:<?= $post['date_of_writing'] ?></p>
    <a id="delet" href="#editing">Редактировать</a>


</div>

<div id="zatemnenie">
    <div id="name">
        <form id="form" action="../../php/addBook.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="name_book" placeholder="Название книги" required><br><br>
            <div id="div">
                <input type="text" name="name0" placeholder="Имя" required><br>
                <input type="text" name="surname0" placeholder="Фамилия" required><br>
                <input type="text" name="sursurname0" placeholder="Отчество"><br><br>

            </div>
            <button type="button" id="add">добавить автора</button>
            <br><br>

            <input type="file" name="img"><br>
            <input type="date" name="date_of_writing" required><BR>
            <textarea name="description" placeholder="Описание" required></textarea><br>


            <button type="submit">Добавить</button>
            <script language="JavaScript">
                let count = 0;
                document.getElementById('add').onclick = function () {
                    let div = document.createElement('div');
                    div.innerHTML = '<input type="text" name="name' + count + '"placeholder="Имя"required><br>' +
                        ' <input type="text" name="surname' + count + '"placeholder="Фамилия"required><br>' +
                        '<input type="text" name="sursurname' + count + '" placeholder="Отчество"><br><br>'
                    count++;
                    document.querySelector('#div').appendChild(div);
                }
            </script>


        </form>
        <a href="#" class="close">Закрыть окно</a>
    </div>
</div>
<div id="editing">
    <div id="name">
        <form id="form" action="../../php/edit_book.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="name_book" placeholder="Название книги" value="<?= $post['name_book'] ?>"><br>
            <br>
            <div id="div">
                <?php foreach ($posts as $post): ?>
                    <input type="text" name="name0" placeholder="Имя" value="<?= $temp['name'] ?>"><br>
                    <input type="text" name="surname0" placeholder="Фамилия" value="<?= $temp['surname'] ?>"<br>
                <?php if(empty($temp['sursurname']))
                    $temp['sursurname']=' '?>
                    <input type="text" name="sursurname0" placeholder="Отчество" value="<?= $temp['sursurname'] ?>"><br>
                    <br>
                <?php endforeach; ?>
            </div>

            <input type="file" name="img"><br>
            <input type="date" name="date_of_writing" value="<?= $post['date_of_writing'] ?>"><BR>
            <textarea name="description" placeholder="Описание"><?= $post['description'] ?></textarea><br>

            <button type="submit">Обновить</button>
            <input type="text" name="id" value="<?= $tmp_a ?>" style="display: none">
            <input type="text" name="id" value="<?= $tmp_a ?>" style="display: none">
            <a href="#" class="close">Закрыть окно</a>
        </form>
        <form action="../../php/delet_book.php" method="POST">
            <input type="text" name="id" value="<?= $tmp_a ?>" style="display: none">
            <button type="submit">Удалить</button>
        </form>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>