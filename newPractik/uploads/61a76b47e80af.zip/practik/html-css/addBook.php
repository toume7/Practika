<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="user/index.css">
    <link rel="stylesheet" href="admin/book.css">
    <title>Document</title>
</head>
<body>
<div id="text">
    <img src="../../uploads/8531d824d8801f3d22c9bfdc778ca608.png">
    <form action="admin/search.php" method="post" enctype="multipart/form-data">
        <input type="text" placeholder="Поиск.." name="search" required>
        <button type="submit">Поиск</button>
    </form>
    <a href="admin/admin.php"><p>Главная</p></a>
    <a href="admin/katalog.php"><p>Каталог</p></a>
    <a href="addBook.php"><p>Добавить книгу</p></a>
    <a href="user/index.php"><p>Выйти</p></a>
</div>
<div id="name">
    <form id="form" action="../php/addBook.php" method="post" enctype="multipart/form-data">
        <input type="text" name="name_book" placeholder="Название книги"><br><br>
        <div id="div">
            <input type="text" name="name0" placeholder="Имя"><br>
            <input type="text" name="surname0" placeholder="Фамилия"><br>
            <input type="text" name="sursurname0" placeholder="Отчество"><br><br>

        </div>
        <button type="button" id="add">добавить автора</button><br><br>

        <input type="file" name="img"><br>
        <input type="date" name="date_of_writing"><BR>
        <textarea name="description" placeholder="Описание"></textarea><br>

        <button type="submit">Добавить</button>
        <script language="JavaScript">
            let count=0;
            document.getElementById('add').onclick=function (){
                let div=document.createElement('div');
                div.innerHTML='<input type="text" name="name'+ count +'"placeholder="Имя"><br>'+
                    ' <input type="text" name="surname'+ count + '"placeholder="Фамилия"><br>'+
                    '<input type="text" name="sursurname'+ count + '" placeholder="Отчество"><br><br>'
                count++;
                document.querySelector('#div').appendChild(div);
            }
        </script>
    </form>
</div>
<form>

</form>
</body>
</html>