<?php
session_start();

require_once "../../php/getnewbook.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="../user/index.css">
    <link rel="stylesheet" href="../user/window.css">
    <link rel="stylesheet" href="../admin/main_book.css">
    <link rel="stylesheet" href="../admin/book.css">
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div id="text">
    <form action="search.php" method="post" enctype="multipart/form-data">
        <input type="text" placeholder="Поиск.." name="search" required>
        <button type="submit">Поиск</button>
    </form>
    <a href="index.php"><p>Главная</p></a>
    <a href="#zatemnenie"><p>Авторизация</p></a>
</div>

<div id="back">

    <?php foreach ($posts

    as $post): ?>
    <img id="photo" src="../../uploads/<?= $post['img']; ?>">
    <h1><?= $post['name_book'] ?></h1>

    <p>Автор(ы):<?php
        $tmp_a = $post['id'];
        $id = $pdo->prepare("SELECT id_autor FROM beetween WHERE `id_book`='$tmp_a'");
        $id->execute();
        $id = $id->FetchAll(PDO::FETCH_ASSOC);
        foreach ($id as $i) {

            $temp_i = $i['id_autor'];
            $ids = intval($temp_i);
            $author = $pdo->prepare("SELECT * FROM author where `id`='$ids'");
            $author->execute();
            $author = $author->FetchAll(PDO::FETCH_ASSOC);
            $temp = $author['0'];
            echo $temp['name'], " ";
            echo $temp['surname'], "  ";


        }
        ?></p></p>
    <div id="div"><p id="description2"><?= $post['description'] ?></p></div>
    <p id="tt">Дата публикации:<?= $post['date_of_writing'] ?></p>

<?php endforeach;?>
</div>

<div id="zatemnenie">
    <form action="../../php/aut.php" method="post" enctype="multipart/form-data">
        <fieldset>
            <p>Ввводите только буквы и цифры</p>
            Name: <input type="text" name="user">
            Password: <input type="password" name="pass">
            <br><br><input  id="log_in"  type="submit" value="log in">
            <a href="#" class="close">Закрыть окно</a>
        </fieldset>
    </form>
</div>


</body>
</html>