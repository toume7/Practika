<?php
session_start();
require_once '../../php/connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="window.css">
    <link rel="stylesheet" href="../admin/book.css">

    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div id="text">
    <form action="search.php" method="post" enctype="multipart/form-data">
        <input type="text" placeholder="Поиск.." name="search" required>
        <button type="submit">Поиск</button>
    </form>
    <a href="index.php"><p>Главная</p></a>
    <a href="#zatemnenie"><p>Авторизация</p></a

</div>


</div>
<div id="main_book">
    <?php
    $booksk=[];
    $name = $_POST['search'];
    $book = $pdo->prepare("SELECT * FROM book where `name_book`='$name'");
    $book->execute();
    $books = $book->FetchAll(PDO::FETCH_ASSOC);
    if (empty($books)) {
        $autor = $pdo->prepare("SELECT * FROM author where `name`='$name' or`surname`='$name' or`sursurname`='$name'");
        $autor->execute();
        $authors = $autor->FetchAll(PDO::FETCH_ASSOC);
        foreach ($authors as $autor) {
            $id_a = $autor['id'];
            $id = $pdo->prepare("SELECT id_book FROM beetween WHERE `id_autor`='$id_a'");
            $id->execute();
            $ids = $id->FetchAll(PDO::FETCH_ASSOC);

            foreach ($ids as $id_b) {
                $temp_id_B = $id_b['id_book'];
                $book = $pdo->prepare("SELECT * FROM book where `id`='$temp_id_B'");
                $book->execute();
                $books = $book->FetchAll(PDO::FETCH_ASSOC);
                $booksk=array_merge($booksk,$books);
            }
        }
    }
    ?>


    <?php foreach ($books as $post): ?>
        <form action="view_book.php" method="POST" enctype="multipart/form-data">
            <div id="book">
                <img id="photo_glav" src="../../uploads/<?= $post['img']; ?>">
                <div id="glav">
                <h2><?= $post['name_book'] ?></h2>
                <p id="description"> Автор(ы):<?php
                    $tmp_a = $post['id'];
                    $id = $pdo->prepare("SELECT id_autor FROM beetween WHERE `id_book`='$tmp_a'");
                    $id->execute();
                    $id = $id->FetchAll(PDO::FETCH_ASSOC);
                    foreach ($id as $i) {
                        $temp_i = $i['id_autor'];
                        $ids = intval($temp_i);
                        $author = $pdo->prepare("SELECT * FROM author where `id`='$ids'");
                        $author->execute();
                        $author = $author->FetchAll(PDO::FETCH_ASSOC);
                        $temp = $author['0'];
                        echo $temp['name'], "  ";

                    }
                    ?></p>
                <p id="description"><?= $post['date_of_writing'] ?></p>
                <button type="submit">Открыть</button>
            </div>
            </div>
            <input id="id5" name="id" value="<?= $tmp_a ?>">
        </form>
    <?php endforeach; ?>
</div>
<div id="zatemnenie">
    <form action="../../php/aut.php" method="post" enctype="multipart/form-data">
        <fieldset>
            <p>Ввводите только буквы и цифры</p>
            Name: <input type="text" name="user">
            Password: <input type="password" name="pass">
            <br><br><input type="submit" value="log in">
            <a href="#" class="close">Закрыть окно</a>
        </fieldset>
    </form>
</div>
</body>
</html>