<?php
session_start();
require_once 'connect.php';
$id = intval($_POST['id']);
$statement = $pdo->prepare("SELECT * FROM book  where `id`='$id'");
$statement->execute();
$posts = $statement->FetchAll(PDO::FETCH_ASSOC);
