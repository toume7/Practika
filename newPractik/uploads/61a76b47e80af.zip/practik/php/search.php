<?php
//require_once "connect.php";
//$name=$_POST['name'];
//$book = $pdo->prepare("SELECT * FROM book where `name_book`='$name'");
//$book->execute();
//$books = $book->FetchAll(PDO::FETCH_ASSOC);
//
//header("location: ../html-css/admin/search.php");
