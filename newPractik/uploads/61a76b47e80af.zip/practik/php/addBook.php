<?php
session_start();
require_once 'connect.php';
$img = $_FILES['img'];
$extension = pathinfo($img['name'], PATHINFO_EXTENSION);
$filename = uniqid() . "." . $extension;
move_uploaded_file($img['tmp_name'], "../uploads/" . $filename);
$idB = checkBookId($_POST['name_book']);
if (empty($idB)) {
    $sql = "INSERT INTO book(name_book,img,date_of_writing,description) VALUE(:name,:img,:date_of_writing,:description)";
    $statement = $pdo->prepare($sql);
    $statement->bindParam(":name", $_POST['name_book']);
    $statement->bindParam(":img", $filename);
    $statement->bindParam(":date_of_writing", $_POST['date_of_writing']);
    $statement->bindParam(":description", $_POST['description']);
    $statement->execute();
}
$id_book = checkBookId($_POST['name_book']);

$count = 0;
while (isset($_POST['name' . $count])) {
    $idA = getAid($_POST['name' . $count], $_POST['surname' . $count], $_POST['sursurname' . $count]);
    if (empty($idA)) {
        $pdo = new PDO("mysql:host=localhost;dbname=practiksavichecv", "root", "root");
        $sql = "INSERT INTO author(name,surname,sursurname) VALUES (:name,:surname,:sursurname)";
        $statement = $pdo->prepare($sql);
        $statement->bindParam(":name", $_POST['name' . $count]);
        $statement->bindParam(":surname", $_POST['surname' . $count]);
        $statement->bindParam(":sursurname", $_POST['sursurname' . $count]);
        $statement->execute();
    }

    $pdo = new PDO("mysql:host=localhost;dbname=practiksavichecv", "root", "root");
    $idA = getAid($_POST['name' . $count], $_POST['surname' . $count], $_POST['sursurname' . $count]);
    $tmp_a = intval(current($idA[array_key_last($idA)]));
    $tmp_b = intval(current($id_book[array_key_last($id_book)]));
    $sql = "INSERT INTO beetween(id_autor,id_book) value ('$tmp_a','$tmp_b')";
    $bd = $pdo->prepare($sql);
    $bd->execute();
    $count++;
}

function checkBookId($name)
{
    $pdo = new PDO("mysql:host=localhost;dbname=practiksavichecv", "root", "root");
    $book = $pdo->prepare("SELECT id FROM book where `name_book`='$name'");
    $book->execute();
    $books = $book->FetchAll(PDO::FETCH_ASSOC);
    if (!empty($books))
        return $books;

}

function getAid($name, $surname, $sursurname)
{
    $pdo = new PDO("mysql:host=localhost;dbname=practiksavichecv", "root", "root");
    $id = $pdo->prepare("SELECT id FROM author where `name`='$name' and `surname`='$surname'and `sursurname`='$sursurname'");
    $id->execute();
    $ids = $id->FetchAll(PDO::FETCH_ASSOC);
    if (!empty($ids))
        return $ids;

}

header("Location:../html-css/admin/admin.php");


